import connectDb from "../_db.js";
import { applyCors } from "../_cors.js";
import Parcel from "../../server/models/Parcel.js";

export default async function handler(req, res) {
  if (applyCors(req, res)) return;
  await connectDb();
  const { id } = req.query;

  if (req.method === "DELETE") {
    await Parcel.findByIdAndDelete(id);
    return res.status(204).end();
  }

  res.setHeader("Allow", "DELETE");
  return res.status(405).json({ error: "Method not allowed" });
}
